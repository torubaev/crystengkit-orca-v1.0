@echo off
setlocal
for %%I in ("%~dp0.") do set "PROJECT_ROOT=%%~fI"
cd /d "%PROJECT_ROOT%"

set "INSTALL_PYTHON_IF_MISSING=0"
set "INSTALL_MSMPI_IF_MISSING=0"
set "CHECKER_ARGS= "--project-root=%PROJECT_ROOT%""
set "PYTHON_INSTALLED_EXE="

:parse_args
if "%~1"=="" goto after_parse
if /i "%~1"=="--install-python-if-missing" (
    set "INSTALL_PYTHON_IF_MISSING=1"
) else if /i "%~1"=="--install-msmpi-if-missing" (
    set "INSTALL_MSMPI_IF_MISSING=1"
) else (
    set "CHECKER_ARGS=%CHECKER_ARGS% %~1"
)
shift
goto parse_args

:after_parse

if "%INSTALL_MSMPI_IF_MISSING%"=="1" call :install_msmpi

rem Prefer the managed environment already installed beside CrystEngKit.
rem This avoids treating every installer upgrade as a new environment setup.
if exist "%PROJECT_ROOT%\.venv\Scripts\python.exe" (
    "%PROJECT_ROOT%\.venv\Scripts\python.exe" -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 9) else 1)" >nul 2>nul
    if not errorlevel 1 (
        "%PROJECT_ROOT%\.venv\Scripts\python.exe" "%PROJECT_ROOT%\install\install.py" --using-venv%CHECKER_ARGS%
        exit /b %errorlevel%
    )
)

where py.exe >nul 2>nul
if not errorlevel 1 (
    py.exe -3 -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 9) else 1)" >nul 2>nul
    if not errorlevel 1 (
        py.exe -3 "%PROJECT_ROOT%\install\install.py"%CHECKER_ARGS%
        exit /b %errorlevel%
    )
)

where python.exe >nul 2>nul
if not errorlevel 1 (
    python.exe -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 9) else 1)" >nul 2>nul
    if not errorlevel 1 (
        python.exe "%PROJECT_ROOT%\install\install.py"%CHECKER_ARGS%
        exit /b %errorlevel%
    )
)

if "%INSTALL_PYTHON_IF_MISSING%"=="1" (
    call :install_python
    set "INSTALL_PYTHON_IF_MISSING=0"
    if not errorlevel 1 (
        if defined PYTHON_INSTALLED_EXE (
            "%PYTHON_INSTALLED_EXE%" "%PROJECT_ROOT%\install\install.py"%CHECKER_ARGS%
            exit /b %errorlevel%
        )
        goto after_parse
    )
)

echo Python 3.9 or newer was not found.
echo Please install Python from https://www.python.org/downloads/windows/
echo During installation, enable "Add python.exe to PATH" and Tcl/Tk support.
pause
exit /b 1

:install_python
echo Python 3.9 or newer was not found.
echo.
echo The installer will try to install Python 3.12 with winget.
echo This requires an internet connection and may show Microsoft Store / winget prompts.
echo.

where winget.exe >nul 2>nul
if errorlevel 1 (
    echo winget was not found on this computer.
    echo Opening the official Python download page instead.
    start "" "https://www.python.org/downloads/windows/"
    exit /b 1
)

winget.exe install --id Python.Python.3.12 -e --source winget --accept-package-agreements --accept-source-agreements
if errorlevel 1 (
    echo Python installation with winget failed.
    echo Opening the official Python download page instead.
    start "" "https://www.python.org/downloads/windows/"
    exit /b 1
)

if exist "%LocalAppData%\Programs\Python\Python312\python.exe" (
    set "PYTHON_INSTALLED_EXE=%LocalAppData%\Programs\Python\Python312\python.exe"
)

echo.
echo Python installation finished. Continuing with the CrystEngKit checker...
exit /b 0

:install_msmpi
where mpiexec.exe >nul 2>nul
if not errorlevel 1 exit /b 0
if exist "%ProgramFiles%\Microsoft MPI\Bin\mpiexec.exe" exit /b 0

echo Microsoft MPI was not found. Installing the Runtime for parallel ORCA calculations...
where winget.exe >nul 2>nul
if errorlevel 1 (
    echo winget was not found. ORCA inputs will default to one process.
    echo Install Microsoft MPI Runtime manually to enable parallel calculations.
    exit /b 0
)

winget.exe install --id Microsoft.msmpi -e --source winget --accept-package-agreements --accept-source-agreements
if errorlevel 1 (
    echo Microsoft MPI installation failed. ORCA inputs will default to one process.
    exit /b 0
)
echo Microsoft MPI Runtime installed. Restart CrystEngKit before running parallel ORCA jobs.
exit /b 0
