param(
    [string]$CertificateThumbprint = $env:CRYSTENGKIT_SIGN_CERT_SHA1,
    [switch]$AllowUnsigned
)

$ErrorActionPreference = "Stop"

$repoRoot = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
$issPath = Join-Path $PSScriptRoot "CrystEngKit_ORCA.iss"
$versionPath = Join-Path $repoRoot "app_metadata\version.json"
$appVersion = (Get-Content -LiteralPath $versionPath -Raw | ConvertFrom-Json).version
if ($appVersion -notmatch '^\d+\.\d+\.\d+$') {
    throw "Invalid application version '$appVersion' in $versionPath. Expected MAJOR.MINOR.PATCH."
}
$releaseDir = Join-Path $repoRoot "install\releases\v$appVersion"
$outputPath = Join-Path $releaseDir "CrystEngKit-ORCA-Setup-$appVersion.exe"
$isccCandidates = @(
    "C:\Program Files (x86)\Inno Setup 6\ISCC.exe",
    (Join-Path $env:LOCALAPPDATA "Programs\Inno Setup 6\ISCC.exe")
)
$iscc = $isccCandidates | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
if (-not $iscc) {
    throw "Inno Setup 6 compiler was not found."
}

$stageRoot = Join-Path $repoRoot "tmp\codex_work\windows_installer_source"
$archivePath = Join-Path $repoRoot "tmp\codex_work\windows_installer_source.zip"
if (Test-Path -LiteralPath $stageRoot) {
    Remove-Item -LiteralPath $stageRoot -Recurse -Force
}
if (Test-Path -LiteralPath $archivePath) {
    Remove-Item -LiteralPath $archivePath -Force
}
New-Item -ItemType Directory -Path (Split-Path $stageRoot) -Force | Out-Null
& git -C $repoRoot archive --format=zip --output=$archivePath HEAD
if ($LASTEXITCODE -ne 0) {
    throw "Could not stage tracked release files from Git HEAD."
}
Expand-Archive -LiteralPath $archivePath -DestinationPath $stageRoot -Force

New-Item -ItemType Directory -Path (Split-Path $outputPath) -Force | Out-Null
& $iscc "/DMyAppVersion=$appVersion" "/DSourceRoot=$stageRoot" $issPath
if ($LASTEXITCODE -ne 0) {
    throw "Inno Setup compilation failed with exit code $LASTEXITCODE."
}

if ($CertificateThumbprint) {
    $certificate = Get-ChildItem Cert:\CurrentUser\My |
        Where-Object { $_.Thumbprint -eq $CertificateThumbprint } |
        Select-Object -First 1
    if (-not $certificate) {
        throw "Code-signing certificate $CertificateThumbprint was not found."
    }
    $signature = Set-AuthenticodeSignature `
        -FilePath $outputPath `
        -Certificate $certificate `
        -TimestampServer "http://timestamp.digicert.com" `
        -HashAlgorithm SHA256
    if ($signature.Status -ne "Valid") {
        throw "Installer signing failed: $($signature.StatusMessage)"
    }
}

$finalSignature = Get-AuthenticodeSignature -FilePath $outputPath
if ($finalSignature.Status -ne "Valid" -and -not $AllowUnsigned) {
    Remove-Item -LiteralPath $outputPath -Force -ErrorAction SilentlyContinue
    throw "The installer is unsigned. Provide -CertificateThumbprint or use -AllowUnsigned."
}

$installerHash = (Get-FileHash -LiteralPath $outputPath -Algorithm SHA256).Hash.ToLowerInvariant()
$checksumPath = "$outputPath.sha256"
Set-Content -LiteralPath $checksumPath -Value "$installerHash  $([IO.Path]::GetFileName($outputPath))" -Encoding ASCII
Write-Host "Built full offline installer: $outputPath"
Write-Host "Installer SHA-256: $installerHash"
Write-Host "Checksum asset: $checksumPath"
Write-Host "Signature status: $($finalSignature.Status)"
